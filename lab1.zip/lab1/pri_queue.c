#include <stdlib.h>
#include <stdio.h>
#include "pri_queue.h"
/** @file pri_queue.c */
static Node_ptr_t head = NULL;
/**
 * Insert a Node into a priority queue.
 * @param priority
 * @param data
 * @author AZMAN NAZIM
 */
void PQ_insert(int priority, char * data) {
 //FIX THIS
    Node_ptr_t new_node, temp;
    new_node = (Node_ptr_t)malloc(sizeof(Node_t)); //Allocate memory for new node
    new_node->priority = priority; //Set the node's priority
    new_node->data = data;         //Set the node's data

    //Check if the head is empty (head is NULL)
    if(head == NULL){
        new_node->next = NULL; //New node becomes the only node in the queue
        head = new_node;	   //Update the head to point to the new node
    }
    //The new node has higher priority than the current head
    else if(head->priority < new_node->priority){
        new_node->next = head; //New node points to the current head
        head = new_node;       //Update the head to the new node
    }
    //Insert the new node in the correct position within the queue
    else{
		//Iterate through the list to find the correct position for the new node
        for(temp = head; temp->next->next != NULL && new_node->priority < temp->next->priority; temp = temp->next){
			//Continue moving through the list until the position is found
        }
        //Insert the new node in its correct position
        new_node->next = temp->next;
        temp->next = new_node;
    }
    
}
/**
 * Delete and return the node with the highest priority.
 * @return The highest priority Node.
 */
Node_ptr_t PQ_delete() {
  //FIX THIS
	if(head == NULL){ //Check if the queue is empty
		return NULL;  //Return NULL if there are no nodes to delete
	}
    Node_ptr_t return_node = head; //Store the current head (highest priority node)
    head = head->next;			   //Update the head to the next node in the list
    return return_node;			   //Return the removed node
}

/**
 * Do NOT modify this function.
 * @return A pointer to the head of the list.  (NULL if list is empty.)
 */
Node_ptr_t PQ_get_head() {
    return head;
}

/**
 * Do NOT modify this function.
 * @return the number of items in the queue
 */
int PQ_get_size() {
    int size = 0;
    Node_ptr_t tmp;
    for(tmp = head; tmp != NULL; tmp = tmp->next, size++)
        ;
    return size;
}


